/*
FPU_RF에서 순차적으로 들어오는 9개의 값을 누적 덧셈한다.
ACC_adder를 instanciation하여 사용.

| Port       | Dir | Width | Description                        |
| ---------- | --- | ----- | ---------------------------------- |
| i_clk      | in  | 1     |                                    |
| i_rstn     | in  | 1     |                                    |
| i_start    | in  | 1     | CONTROL에서 보내는 시작 신호              |
| i_data     | in  | 9     | FPU_RF에서 순차적으로 들어오는 값            |
| o_result   | out | 9     | 누적 덧셈 결과                          |
| o_done     | out | 1     | 9개 누적 완료 신호 → CONTROL로            |
*/

`timescale 1ns / 1ps

module ACC (
    input            i_clk,
    input            i_rstn,
    input            i_start,
    input      [8:0] i_data[8:0],
    output reg [8:0] o_result,
    output reg       o_done
);

// 내부 신호
reg [3:0] wait_cnt;   // start 후 2사이클 대기용
reg [3:0] acc_cnt;    // 누적 카운터 (0~8)
reg       active;     // 누적 진행 중
reg [8:0] acc_reg;    // 누적값 저장

// ACC_adder 조합 로직 인스턴스
wire [8:0] adder_result;

ACC_adder u_adder (
    .i_a     (acc_reg),
    .i_b     (i_data[acc_cnt]),
    .o_result(adder_result)
);

always @(posedge i_clk or negedge i_rstn) begin
    if (!i_rstn) begin
        wait_cnt <= 4'd0;
        acc_cnt  <= 4'd0;
        active   <= 1'b0;
        acc_reg  <= 9'd0;
        o_result <= 9'd0;
        o_done   <= 1'b0;
    end else if (i_start && !active) begin
        // start 수신: 카운터 초기화, 대기 시작
        wait_cnt <= 4'd1;
        acc_cnt  <= 4'd0;
        active   <= 1'b1;
        acc_reg  <= 9'd0;
        o_done   <= 1'b0;
    end else if (active) begin
        // 누적 연산
        acc_reg <= adder_result;
        acc_cnt <= acc_cnt + 4'd1;

        if (acc_cnt == 4'd8) begin
            // 9개 누적 완료
            o_result <= adder_result;
            o_done   <= 1'b1;
            active   <= 1'b0;
            end
    end else begin
        o_done <= 1'b0;
    end
end

endmodule